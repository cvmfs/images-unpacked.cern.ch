#! /bin/bash

gnuplot<<EOF
set term epslatex standalone lw 1 size 3.375in,2.98129921259843in font ',9'
set output "2piTDs.tex"
Nc=3.
nf=3.
Lambda=332.
b0=(11-2*nf/3.)/(4*pi)**2
b1=(102-38*nf/3.)/(4*pi)**4
g2(x)=1/(2*b0*log(x/Lambda)+b1/b0*log(2*log(x/Lambda)))
#print(g2(3000)/4/pi)
# Md for Nf=3
mD(x)=sqrt(1.5*g2(x))
#mD for Nf=0
#mD(x)=sqrt(g2(x))
#Simon Caron-Huot, Guy D. Moore, 	arXiv:0801.2173 [hep-ph]
mu=2*pi
xi=-0.64718
CC=2.3302
kappaNLO(x,mu)=(16*pi/3.)*(g2(x*mu)/(4*pi))**2*(log(1/g2(x*mu))/2. + 0.07428 + 1.9026*sqrt(g2(x*mu)))
kappa1(x)=4./3.*g2(mu*x)**2/(18*pi)*( (Nc+nf/2)*(log(2/mD(x*mu))+xi)+nf*log(2)/2.+Nc*mD(x*mu)*CC )
Ds(x,mu)=4*pi/kappaNLO(x,mu)

#set size 0.8, 1
set xr [0.9:2.6]
set yr [0:14.5]
set xlabel '\$T/T_c\$'
set ylabel '\$2\pi TD_s\$'
set key samplen 0.8
set pointsize 1.6
set key at 1.8,14
set mxtics
set mytics
set key spacing 1.2

set arrow from 0.9,4*pi/14 to 1.5,4*pi/14 nohead lt -1 lw 3
set label "AdS/CFT" at 1.55,1
set label "T-matrix" at 2.3,5.0
set label "Bayesian" at 2.1,10
set label "pert. NLO" at 2.2,3.0

p 'Duke_Bayesian.dat' u 1:2:3 not w filledcu lc rgb "#FFBBFF",\
 'Tmat-Ds2piT.dat' u (\$1/156.):2:3 not w filledcu lc rgb "#BBFFBB",\
 "NLO_2piT.dat" u 1:2 not w l lt -0 lw 16,\
 "NLO_4piT.dat" u 1:2 not w l lt -0 lw 16,\
 '2piTDs.dat' u (\$1/180):((4*pi/(\$2-\$3)+4*pi/(\$2+\$3))/2):((4*pi/(\$2-\$3)-4*pi/(\$2+\$3))/2) t '\$N_f=2+1\ \mathrm{QCD}\$' w e pt 7 lc rgb "#FF0000" lw 4,\
 'quenched_combo_2piTDs.dat' u 1:((\$2+\$3)/2.):((\$3-\$2)/2.) t '\$N_f=0\ \mathrm{QCD}\$' w e pt 6 lc rgb "#0000FF" lw 4,\
 'ALICE.dat' u 1:((\$2+\$3)/2):((\$3-\$2)/2) t "ALICE" w e pt 2 lc rgb "#00AA00" lw 4

#pause -1
#set term post eps enh color 20
#set out '2piTDs.eps'
#rep
set output
quit
EOF
pdflatex 2piTDs.tex
rm *.log *-inc-eps-converted-to.pdf *.eps  *.tex *.aux 
